//
//  RotateView.swift
//  RotateAnimation
//
//  Created by elevenjian on 2017/2/24.
//  Copyright © 2017年 elevenjian. All rights reserved.
//

import UIKit


let SCREEN_WIDTH = UIScreen.mainScreen().bounds.width//屏幕宽

let SCREEN_HEIGHT = UIScreen.mainScreen().bounds.height//屏幕高

let CENTER = CGPoint(x:SCREEN_WIDTH/2, y:SCREEN_HEIGHT/2)//屏幕中心点

let RADIUS = SCREEN_WIDTH/2

let IMAGE_LENGTH:CGFloat = 40//图片边长


class RotateView: UIView {
    
    let image = UIImage(named: "image")
    
    var count = 1 // 图片数量
    
    var images:[MoveImage] = []// 图片对象数组
    
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        defaultView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
  
    //MARK:图片拖动时的回调
    internal override func touchesMoved(touches: Set<UITouch>, withEvent event: UIEvent?) {
        nextResponder()?.touchesMoved(touches, withEvent: event)

        
        guard let moveImage = touches.first?.view as? MoveImage else{return}
            
        let touch = touches.first
        //当拖动超过边界时返回
        //        let prePointInSelf = touch?.previousLocationInView(self)
//        guard  CGRectContainsRect(bounds, moveImage.frame) || curPointInSelf?.distanceBetweenTwoPoints(CENTER)<prePointInSelf?.distanceBetweenTwoPoints(CENTER) else{ return}
        
        //根据拖拽进行视图位移
        let curPoint = touch?.locationInView(moveImage)
        let prePoint = touch?.previousLocationInView(moveImage)
        let offX = curPoint!.x - (prePoint?.x)!
        let offY = (curPoint?.y)! - (prePoint?.y)!
        for image in images{
            image.transform = CGAffineTransformTranslate(image.transform, offX, offY)

        }
        
        
        
        
    }
    
    //MARK:初始化时，默认右边一张图片
    func defaultView() {
        
        frame = CGRectMake(0, CENTER.y-RADIUS, SCREEN_WIDTH, SCREEN_WIDTH)
        backgroundColor = UIColor.lightGrayColor()
        let moveImage = MoveImage(image: image)
        
        moveImage.frame = CGRectMake(0, 0, IMAGE_LENGTH, IMAGE_LENGTH)
        moveImage.center = CGPoint(x: RADIUS*1.5, y: RADIUS)
        images.append(moveImage)
        addSubview(moveImage)

    }
    //MARK:图片数目变化
    func updateNum(count:Int){
        
        for item in subviews {
            
            item.removeFromSuperview()
            
        }
        
        images = []
        
        for i in 0..<count {
            
            let moveImage = MoveImage(image: image)
            moveImage.frame = CGRectMake(0, 0, IMAGE_LENGTH, IMAGE_LENGTH)
            moveImage.center = CGPoint(x: RADIUS*1.5, y: RADIUS)
            let angle = CGFloat(i)/CGFloat(count) * CGFloat(M_PI) * 2.0
            let trans = moveImage.rotateAroundPoint(CGAffineTransformIdentity, x: RADIUS, y: RADIUS, angle: angle)
            moveImage.transform = trans
            images.append(moveImage)
            addSubview(moveImage)

        }
    }
    
    // MARK:重写方法，实现MoveImage超出父视图时事件的传递
    override func pointInside(point: CGPoint, withEvent event: UIEvent?) -> Bool {
        
        for view in subviews{
            
            if CGRectContainsPoint(view.frame, point){
                return true
            }
        }
        return false
        
    }
    
    

    
    
}



class MoveImage:UIImageView{
    
   
    
    override init(image: UIImage?) {
        super.init(image: image)
        userInteractionEnabled = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }

    internal override func touchesMoved(touches: Set<UITouch>, withEvent event: UIEvent?) {
        
       nextResponder()?.touchesMoved(touches, withEvent: event)
    }
    
    
}


extension MoveImage{
    
    //MARK: 以(centerX,centerY)为中心的UIView绕(x,y)顺时针旋转angle弧度
    func rotateAroundPoint(transform:CGAffineTransform,x:CGFloat,y:CGFloat,angle:CGFloat) -> CGAffineTransform {
        
        let dx = x - center.x
        let dy = y - center.y
        //center平移到(x,y)
        var trans = CGAffineTransformTranslate(CGAffineTransformIdentity, dx, dy)
        //旋转
        trans = CGAffineTransformRotate(trans, angle)
        //center还原
        trans = CGAffineTransformTranslate(trans, -dx, -dy)
        return trans
        
    }
   
}

extension CGPoint{
    //MARK: 计算两点之间距离
    func distanceBetweenTwoPoints(point:CGPoint) -> CGFloat {
        
         return sqrt((point.x - x)*(point.x - x) + (point.y - y)*(point.y - y))
        
    }
}
