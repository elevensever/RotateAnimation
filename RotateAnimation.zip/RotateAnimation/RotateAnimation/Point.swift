//
//  Point.swift
//  RotateAnimation
//
//  Created by elevenjian on 2017/2/24.
//  Copyright © 2017年 elevenjian. All rights reserved.
//

import Foundation
import UIKit

struct Point {
    var x:CGFloat
    var y:CGFloat
}


